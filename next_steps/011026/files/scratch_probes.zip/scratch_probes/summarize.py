import json, glob, numpy as np
recs = []
for f in sorted(glob.glob("probe_p10_C_ID_k*.json")):
    recs += json.load(open(f))
# de-duplicate (k, rep)
seen = {}
for r in recs: seen[(r["k"], r["rep"])] = r
R = list(seen.values()); n = len(R); print("datasets:", n)

def paired(a, b):
    d = np.array(a) - np.array(b); return d.mean(), d.std(ddof=1)/np.sqrt(len(d)), np.mean(d > 0)
for pen in ("MCP", "SCAD"):
    for met in ("max_f1", "auc"):
        m, se, fb = paired([r[pen][met] for r in R], [r["lasso"][met] for r in R])
        print(f"{pen}-lasso {met:6s}: {m:+.3f} (se {se:.3f}, z {m/se:+.1f}), {pen} better on {fb:.0%}")
print()
print("means at each method's best-F1 point:")
print(f"{'':6s} {'max_f1':>7s} {'auc':>6s} {'TP':>5s} {'FP':>5s} {'revFP':>6s} {'FN':>5s} {'revFN':>6s} {'skelF1':>7s} {'oriAcc':>7s} {'denseTPR':>9s} {'dense both-dir pairs':>21s}")
for pen in ("lasso", "MCP", "SCAD"):
    g = lambda key: np.nanmean([r[pen][key] for r in R])
    print(f"{pen:6s} {g('max_f1'):7.3f} {g('auc'):6.3f} {g('tp_best'):5.1f} {g('fp'):5.1f} {g('rev_fp'):6.1f} {g('fn'):5.1f} {g('rev_fn'):6.1f} {g('sk_f1'):7.3f} {g('ori_acc'):7.3f} {g('dense_tpr'):9.3f} {g('dense_pairs_both'):21.1f}")
print("mean #true edges:", np.mean([r["n_true"] for r in R]), " dense nnz:", np.mean([r["lasso"]["dense_nnz"] for r in R]))

kt = np.array([r["kappa_true_median"] for r in R if r["kappa_true_median"] is not None])
fb = np.array([r["frac_kappa_below_1_3"] for r in R if r["frac_kappa_below_1_3"] is not None])
print(f"\nswap curvature on true edges: median over datasets of per-dataset median kappa = {np.median(kt):.3f};"
      f" fraction of true edges with kappa < 1/3: mean {fb.mean():.2f} (range {fb.min():.2f}-{fb.max():.2f})")
print("median kappa over all pairs:", np.median([r["kappa_all_median"] for r in R]).round(3))
d = np.array([r["MCP"]["max_f1"] - r["lasso"]["max_f1"] for r in R])
print("corr(frac kappa<1/3, MCP-lasso max_f1) =", np.corrcoef(fb, d)[0,1].round(2))
d_auc = np.array([r["MCP"]["auc"] - r["lasso"]["auc"] for r in R])
print("corr(frac kappa<1/3, MCP-lasso auc) =", np.corrcoef(fb, d_auc)[0,1].round(2))
# by k
for k in (1,2,3,4):
    Rk = [r for r in R if r["k"] == k]
    print(f"k={k}: frac kappa<1/3 {np.mean([r['frac_kappa_below_1_3'] for r in Rk]):.2f}, "
          f"MCP-lasso max_f1 {np.mean([r['MCP']['max_f1']-r['lasso']['max_f1'] for r in Rk]):+.3f}, "
          f"auc {np.mean([r['MCP']['auc']-r['lasso']['auc'] for r in Rk]):+.3f}")

A = [r["MCP_at_best"] for r in R]
lower = np.mean([a["F_oracle_basin"] < a["F_path"] - 1e-9 for a in A])
print(f"\nMCP at its best-F1 lambda: oracle-basin objective lower than continuation's on {lower:.0%} of datasets")
print(f"  F1 continuation {np.mean([a['f1_path'] for a in A]):.3f}  vs oracle-basin {np.mean([a['f1_oracle_basin'] for a in A]):.3f}")
lo = [a for a in A if a["F_oracle_basin"] < a["F_path"] - 1e-9]
hi = [a for a in A if not (a["F_oracle_basin"] < a["F_path"] - 1e-9)]
print(f"  where oracle basin is lower: F1 path {np.mean([a['f1_path'] for a in lo]):.3f} -> oracle {np.mean([a['f1_oracle_basin'] for a in lo]):.3f} (n={len(lo)})")
print(f"  where path is lower       : F1 path {np.mean([a['f1_path'] for a in hi]):.3f} -> oracle {np.mean([a['f1_oracle_basin'] for a in hi]):.3f} (n={len(hi)})")
F = [r["MCP_at_best"] for r in R if r["k"] in (1,2)]
dd = np.array([a["f1_after_flips"] - a["f1_path"] for a in F])
print(f"\nreversal search (k=1,2; n={len(F)}): flips accepted on {np.mean([a['n_flips']>0 for a in F]):.0%};"
      f" F1 change mean {dd.mean():+.3f}; better {np.mean(dd>1e-9):.0%}, worse {np.mean(dd<-1e-9):.0%}")
