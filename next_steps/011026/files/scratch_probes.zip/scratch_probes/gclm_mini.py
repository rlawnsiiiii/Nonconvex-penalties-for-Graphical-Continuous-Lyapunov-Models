"""Minimal, independent re-implementation of the S1/S1b setup for quick probes.

Mirrors the repo's DGP (same seeding scheme), Dettling's direct loss with the
diagonal unpenalised, textbook MCP/SCAD, continuation from lambda_max with warm
starts.  Not the repo's code -- only for checking mechanisms.
"""
from __future__ import annotations

import numpy as np
from scipy.linalg import solve_continuous_lyapunov

CCHOICES = ["C_ID", "C_Random_Diag", "C_Random_Min_Diag", "C_Random_Full"]
SEED = 20260922


# ----------------------------------------------------------------------------- DGP
def sample_drift(p, d, rng):
    eps = rng.normal(size=(p, p))
    omega = rng.binomial(1, d, size=(p, p))
    off = omega * eps
    np.fill_diagonal(off, 0.0)
    m = off.copy()
    np.fill_diagonal(m, -np.abs(off).sum(axis=1) - np.abs(np.diag(eps)))
    return m


def sample_volatility(p, choice, rng):
    if choice == "C_ID":
        return 2.0 * np.eye(p)
    if choice == "C_Random_Diag":
        return np.diag(rng.uniform(0.5, 4.0, size=p))
    if choice == "C_Random_Min_Diag":
        return np.diag(rng.uniform(2.0, 4.0, size=p))
    eps = rng.normal(size=(p, p))
    omega = rng.binomial(1, min(2.0 / p, 1.0), size=(p, p))
    w = omega * eps
    np.fill_diagonal(w, 0.0)
    c = w + w.T
    np.fill_diagonal(c, np.abs(c).sum(axis=1) + np.abs(np.diag(eps)) + 0.5)
    return c


def solve_lyapunov(m, c):
    s = solve_continuous_lyapunov(m, -c)          # M S + S M' = -C
    return 0.5 * (s + s.T)


def draw(p, k, c_choice, rep, n=1000, standardize=True):
    rng = np.random.default_rng([SEED, p, k, CCHOICES.index(c_choice), rep])
    m = sample_drift(p, k / p, rng)
    c = sample_volatility(p, c_choice, rng)
    sig = solve_lyapunov(m, c)
    if n is None or not np.isfinite(n):
        sh = sig.copy()
    else:
        x = rng.multivariate_normal(np.zeros(p), sig, size=int(n), method="cholesky")
        sh = x.T @ x / x.shape[0]
    if standardize:
        s = np.sqrt(np.diag(sh))
        sh = sh / np.outer(s, s)
    return m, c, sig, sh


# ----------------------------------------------------------------------------- loss
def resid(m, sh, c):
    return m @ sh + sh @ m.T + c


def loss(m, sh, c):
    r = resid(m, sh, c)
    return 0.5 * float(np.sum(r * r))


def grad(m, sh, c):
    return 2.0 * resid(m, sh, c) @ sh


def lipschitz(sh):
    return (2.0 * np.linalg.eigvalsh(sh)[-1]) ** 2


def diagonal_fit(sh, c):
    p = sh.shape[0]
    rows, y = [], []
    for k in range(p):
        for l in range(p):
            a = np.zeros(p)
            a[k] += sh[k, l]
            a[l] += sh[k, l]
            rows.append(a)
            y.append(-c[k, l])
    d = np.linalg.lstsq(np.array(rows), np.array(y), rcond=None)[0]
    return np.diag(d)


def lambda_max(sh, c):
    g = grad(diagonal_fit(sh, c), sh, c)
    np.fill_diagonal(g, 0.0)
    return float(np.max(np.abs(g)))


# ----------------------------------------------------------------------------- penalties
def pen_value(m, lam, w, penalty, gamma):
    x = np.abs(m)
    if penalty == "lasso":
        v = lam * x
    elif penalty == "MCP":
        v = np.where(x <= gamma * lam, lam * x - x * x / (2 * gamma), 0.5 * gamma * lam * lam)
    elif penalty == "SCAD":
        v = np.where(x <= lam, lam * x,
                     np.where(x <= gamma * lam,
                              (2 * gamma * lam * x - x * x - lam * lam) / (2 * (gamma - 1)),
                              0.5 * lam * lam * (gamma + 1)))
    else:
        raise ValueError(penalty)
    return float(np.sum(w * v))


def prox(z, t, lam_w, penalty, gamma):
    """Elementwise prox of t*P_{lam_w} (lam_w = lam * weight, per entry; weight 0 -> identity)."""
    a = np.abs(z)
    s = np.sign(z)
    if penalty == "lasso":
        return s * np.maximum(a - t * lam_w, 0.0)
    if penalty == "MCP":
        out = np.where(a <= t * lam_w, 0.0,
                       np.where(a <= gamma * lam_w, s * (a - t * lam_w) / (1.0 - t / gamma), z))
        return np.where(lam_w == 0, z, out)
    if penalty == "SCAD":
        out = np.where(a <= (1 + t) * lam_w, s * np.maximum(a - t * lam_w, 0.0),
                       np.where(a <= gamma * lam_w,
                                s * ((gamma - 1) * a - t * gamma * lam_w) / (gamma - 1 - t), z))
        return np.where(lam_w == 0, z, out)
    raise ValueError(penalty)


# ----------------------------------------------------------------------------- solvers
def fista_wlasso(sh, c, lam_w, m0, tol=1e-8, max_iter=200_000):
    """FISTA with gradient restart for a weighted lasso (lam_w is the per-entry lambda)."""
    t_step = 1.0 / lipschitz(sh)
    m = m0.copy()
    y = m.copy()
    t = 1.0
    for _ in range(max_iter):
        m_new = prox(y - t_step * grad(y, sh, c), t_step, lam_w, "lasso", None)
        if np.sum((y - m_new) * (m_new - m)) > 0:
            t_next = 1.0
            y = m_new.copy()
        else:
            t_next = 0.5 * (1.0 + np.sqrt(1.0 + 4.0 * t * t))
            y = m_new + ((t - 1.0) / t_next) * (m_new - m)
        delta = np.max(np.abs(m_new - m))
        m, t = m_new, t_next
        if delta < tol:
            break
    return m


def mapg(sh, c, lam, w, penalty, gamma, m0, tol=1e-8, max_iter=200_000):
    """Monotone APG (Li & Lin 2015, Alg. 1) for MCP / SCAD."""
    a = 1.0 / lipschitz(sh)
    lam_w = lam * w

    def F(m):
        return loss(m, sh, c) + pen_value(m, lam, w, penalty, gamma)

    x = m0.copy()
    x_prev = x.copy()
    z = x.copy()
    t_prev, t = 0.0, 1.0
    fx = F(x)
    for _ in range(max_iter):
        y = x + (t_prev / t) * (z - x) + ((t_prev - 1.0) / t) * (x - x_prev)
        z = prox(y - a * grad(y, sh, c), a, lam_w, penalty, gamma)
        v = prox(x - a * grad(x, sh, c), a, lam_w, penalty, gamma)
        fz, fv = F(z), F(v)
        x_new, f_new = (z, fz) if fz <= fv else (v, fv)
        t_prev, t = t, (np.sqrt(4 * t * t + 1) + 1) / 2
        delta = np.max(np.abs(x_new - x))
        x_prev, x, fx = x, x_new, f_new
        if delta < tol:
            break
    return x


def default_gamma(penalty):
    return {"MCP": 3.0, "SCAD": 3.7}.get(penalty)


def path(sh, c, penalty="lasso", gamma=None, n_lambda=100, ratio=1e-4, tol=1e-8, lams=None):
    p = sh.shape[0]
    w = np.ones((p, p))
    np.fill_diagonal(w, 0.0)
    gamma = gamma if gamma is not None else default_gamma(penalty)
    lmax = lambda_max(sh, c)
    if lams is None:
        lams = lmax * 10 ** np.linspace(-4, 0, n_lambda) if ratio == 1e-4 else \
            lmax * np.logspace(np.log10(ratio), 0, n_lambda)
    order = np.argsort(-lams)
    warm = diagonal_fit(sh, c)
    est = [None] * len(lams)
    for i in order:
        if lams[i] >= lmax * (1 - 1e-12):
            warm = diagonal_fit(sh, c)
        elif penalty == "lasso":
            warm = fista_wlasso(sh, c, lams[i] * w, warm, tol=tol)
        else:
            warm = mapg(sh, c, lams[i], w, penalty, gamma, warm, tol=tol)
        est[i] = warm.copy()
    return np.asarray(lams), est


# ----------------------------------------------------------------------------- metrics
def offdiag_support(m, zt=1e-10):
    s = np.abs(m) > zt
    np.fill_diagonal(s, False)
    return s


def confusion(est_m, m_true):
    p = m_true.shape[0]
    off = ~np.eye(p, dtype=bool)
    truth = (m_true != 0) & off
    s = offdiag_support(est_m)
    tp = int(np.sum(s & truth))
    fp = int(np.sum(s & ~truth & off))
    fn = int(np.sum(~s & truth))
    tn = int(np.sum(~s & ~truth & off))
    return tp, fp, fn, tn


def f1(tp, fp, fn):
    d = 2 * tp + fp + fn
    return 2 * tp / d if d > 0 else 0.0


def path_metrics(lams, est, m_true):
    """max_f1, auc (path order sparse->dense, anchored at (0,0) and (1,1)), best index."""
    order = np.argsort(-lams)  # sparse -> dense
    pts, f1s = [(0.0, 0.0)], []
    for i in order:
        tp, fp, fn, tn = confusion(est[i], m_true)
        tpr = tp / (tp + fn) if tp + fn > 0 else 1.0
        fpr = fp / (fp + tn) if fp + tn > 0 else 1.0
        pts.append((fpr, tpr))
        f1s.append(f1(tp, fp, fn))
    pts.append((1.0, 1.0))
    pts = np.array(pts)
    auc = float(np.sum(np.diff(pts[:, 0]) * (pts[1:, 1] + pts[:-1, 1]) / 2))
    j = int(np.argmax(f1s))
    return {"max_f1": float(f1s[j]), "auc": auc, "best": int(order[j])}


def orientation_breakdown(est_m, m_true):
    """Split errors into reversals vs. skeleton errors; skeleton F1; orientation accuracy."""
    p = m_true.shape[0]
    off = ~np.eye(p, dtype=bool)
    truth = (m_true != 0) & off
    s = offdiag_support(est_m)
    fp = s & ~truth & off
    fn = truth & ~s
    rev_fp = int(np.sum(fp & truth.T))          # (i,j) selected, only (j,i) true
    rev_fn = int(np.sum(fn & s.T))              # (i,j) true & missed, (j,i) selected
    sk_true = np.triu(truth | truth.T, 1)
    sk_sel = np.triu(s | s.T, 1)
    sk_tp = int(np.sum(sk_true & sk_sel))
    sk_f1 = f1(sk_tp, int(np.sum(sk_sel & ~sk_true)), int(np.sum(sk_true & ~sk_sel)))
    # orientation accuracy among true edges whose pair is in the selected skeleton
    pair_hit = truth & (s | s.T)
    oriented = truth & s
    ori_acc = float(np.sum(oriented) / np.sum(pair_hit)) if np.sum(pair_hit) else np.nan
    return {"fp": int(np.sum(fp)), "rev_fp": rev_fp, "fn": int(np.sum(fn)), "rev_fn": rev_fn,
            "sk_f1": sk_f1, "ori_acc": ori_acc}


def swap_curvature(sh):
    """kappa_ij = ||[V_ij, Sigma]||_F^2 / ||V_ij||_F^2 for V_ij = e_i e_j' - e_j e_i'.

    Curvature of the direct loss along the edge-reversal direction (move mass from
    M_ij to M_ji).  MCP is concave along that segment with curvature -1/gamma, so the
    penalised objective is concave there iff kappa_ij < 1/gamma.
    """
    p = sh.shape[0]
    kap = np.full((p, p), np.nan)
    for i in range(p):
        for j in range(i + 1, p):
            v = np.zeros((p, p))
            v[i, j], v[j, i] = 1.0, -1.0
            x = v @ sh - sh @ v
            kap[i, j] = kap[j, i] = 0.5 * float(np.sum(x * x))
    return kap
