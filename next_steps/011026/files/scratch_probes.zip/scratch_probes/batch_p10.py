"""Probe on the Dettling DGP, p=10, C_ID, k=1..4, reps 0..9 (40 datasets, same draws as the repo)."""
import numpy as np, json, sys, time
from gclm_mini import *

p = int(sys.argv[1]) if len(sys.argv) > 1 else 10
reps = int(sys.argv[2]) if len(sys.argv) > 2 else 10
cchoice = sys.argv[3] if len(sys.argv) > 3 else "C_ID"
ks = [int(x) for x in sys.argv[4].split(",")] if len(sys.argv) > 4 else [1, 2, 3, 4]
out = []
C = 2 * np.eye(p)
w = np.ones((p, p)); np.fill_diagonal(w, 0)
off = ~np.eye(p, dtype=bool)

def oracle_ls(sh, truth):
    """Least-squares fit of the direct loss on (true support U diagonal)."""
    cols, idx = [], []
    for i in range(p):
        for j in range(p):
            if i == j or truth[i, j]:
                E = np.zeros((p, p)); E[i, j] = 1.0
                cols.append((E @ sh + sh @ E.T).ravel()); idx.append((i, j))
    beta = np.linalg.lstsq(np.column_stack(cols), -C.ravel(), rcond=None)[0]
    m = np.zeros((p, p))
    for (i, j), b in zip(idx, beta): m[i, j] = b
    return m

t_start = time.time()
for k in ks:
    for rep in range(reps):
        m_true, _, _, sh = draw(p, k, cchoice, rep)
        truth = (m_true != 0) & off
        kap = swap_curvature(sh)
        kt = kap[truth]
        rec = {"p": p, "k": k, "rep": rep, "n_true": int(truth.sum()),
               "kappa_true_median": float(np.median(kt)) if kt.size else None,
               "frac_kappa_below_1_3": float(np.mean(kt < 1/3)) if kt.size else None,
               "frac_kappa_below_1_27": float(np.mean(kt < 1/2.7)) if kt.size else None,
               "kappa_all_median": float(np.nanmedian(kap[off]))}
        res = {}
        for pen in ("lasso", "MCP", "SCAD"):
            lams, est = path(sh, C, pen)
            r = path_metrics(lams, est, m_true)
            b = r["best"]
            ob = orientation_breakdown(est[b], m_true)
            dense = est[int(np.argmin(lams))]
            tp, fp, fn, tn = confusion(dense, m_true)
            s = offdiag_support(dense)
            both = int(np.sum(np.triu(s & s.T, 1)))
            rec[pen] = {"max_f1": r["max_f1"], "auc": r["auc"], "best_idx": b, "best_lam_rel": float(lams[b]/lams.max()),
                        **ob, "tp_best": int(np.sum(offdiag_support(est[b]) & truth)),
                        "dense_tpr": tp / max(tp + fn, 1), "dense_nnz": int(s.sum()), "dense_pairs_both": both}
            res[pen] = (lams, est)
        # MCP at its own best-F1 lambda: continuation solution vs. oracle-basin solution, and reversal search
        lams, est = res["MCP"]; b = rec["MCP"]["best_idx"]; lam = lams[b]
        Fm = lambda m: loss(m, sh, C) + pen_value(m, lam, w, "MCP", 3.0)
        m_path = est[b]
        m_orc = mapg(sh, C, lam, w, "MCP", 3.0, oracle_ls(sh, truth), tol=1e-9)
        cur = m_path.copy(); n_flips = 0; improved = True
        import os
        max_flips = int(os.environ.get('MAX_FLIPS', '20'))
        while improved and n_flips < max_flips:
            improved = False
            sel = list(zip(*np.nonzero(offdiag_support(cur))))
            for (i, j) in sel:
                trial = cur.copy(); trial[j, i], trial[i, j] = trial[j, i] + trial[i, j], 0.0
                sol = mapg(sh, C, lam, w, "MCP", 3.0, trial, tol=1e-8, max_iter=20_000)
                if Fm(sol) < Fm(cur) - 1e-10:
                    cur, improved, n_flips = sol, True, n_flips + 1
                    break
        def f1_of(m):
            tp, fp, fn, tn = confusion(m, m_true); return f1(tp, fp, fn)
        rec["MCP_at_best"] = {"F_path": Fm(m_path), "F_oracle_basin": Fm(m_orc),
                              "f1_path": f1_of(m_path), "f1_oracle_basin": f1_of(m_orc),
                              "F_after_flips": Fm(cur), "f1_after_flips": f1_of(cur), "n_flips": n_flips,
                              "rev_fp_after": orientation_breakdown(cur, m_true)["rev_fp"]}
        out.append(rec)
        print(f"k={k} rep={rep}  lasso {rec['lasso']['max_f1']:.3f}  MCP {rec['MCP']['max_f1']:.3f}  "
              f"SCAD {rec['SCAD']['max_f1']:.3f} | flips {n_flips}: f1 {rec['MCP_at_best']['f1_path']:.3f}"
              f"->{rec['MCP_at_best']['f1_after_flips']:.3f} | F path {rec['MCP_at_best']['F_path']:.4f} "
              f"oracle {rec['MCP_at_best']['F_oracle_basin']:.4f}  [{time.time()-t_start:.0f}s]", flush=True)
        json.dump(out, open(f"probe_p{p}_{cchoice}_k{'-'.join(map(str,ks))}.json", "w"))
print("done")
