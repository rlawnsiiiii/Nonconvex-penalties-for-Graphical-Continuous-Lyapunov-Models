import numpy as np, time
from gclm_mini import *

# 1) closed form of kappa for a correlation matrix
m, c, sig, sh = draw(10, 2, "C_ID", 0)
kap = swap_curvature(sh)
p = sh.shape[0]
i, j = 2, 7
cf = sum(sh[i,k]**2 + sh[j,k]**2 for k in range(p) if k not in (i,j)) + 4*sh[i,j]**2
print("kappa numeric vs closed form:", kap[i,j], cf)

# 2) Example 2 (Dettling): path and 5-cycle, population covariance, C = 2I
def ex2(cycle):
    M = np.diag([-2.,-3.,-4.,-5.,-6.])
    for a in range(4): M[a+1, a] = 0.65
    if cycle: M[0, 4] = 0.65
    return M
for name, cyc in [("path", False), ("cycle", True)]:
    M = ex2(cyc); C = 2*np.eye(5); S = solve_lyapunov(M, C)
    for pen in ["lasso", "MCP", "SCAD"]:
        t0 = time.time()
        lams, est = path(S, C, pen, tol=1e-10)
        r = path_metrics(lams, est, M)
        print(f"{name:5s} {pen:5s} max_f1={r['max_f1']:.3f} auc={r['auc']:.3f}  ({time.time()-t0:.1f}s)")
