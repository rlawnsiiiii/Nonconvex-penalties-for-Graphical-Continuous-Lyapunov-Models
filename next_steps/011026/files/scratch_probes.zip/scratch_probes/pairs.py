"""Pair-level decomposition at each method's best-F1 point: single edges vs. 2-cycles."""
import numpy as np, json, sys, time
from gclm_mini import *
p = int(sys.argv[1]); ks = [int(x) for x in sys.argv[2].split(",")]; reps = int(sys.argv[3])
pens = sys.argv[4].split(",") if len(sys.argv) > 4 else ["lasso", "MCP"]
C = 2*np.eye(p); off = ~np.eye(p, dtype=bool)
out = []; t0 = time.time()
for k in ks:
    for rep in range(reps):
        m_true, _, _, sh = draw(p, k, "C_ID", rep)
        T = (m_true != 0) & off
        uni = T & ~T.T                     # single edges (reverse absent)
        bi = np.triu(T & T.T, 1)           # 2-cycles, counted once per pair
        # design-column correlation between M_ij and M_ji
        cors = []
        for i in range(p):
            for j in range(i+1, p):
                Ea = np.zeros((p,p)); Ea[i,j] = 1; Eb = np.zeros((p,p)); Eb[j,i] = 1
                a = (Ea@sh + sh@Ea.T).ravel(); b = (Eb@sh + sh@Eb.T).ravel()
                cors.append(a@b/np.sqrt((a@a)*(b@b)))
        rec = {"k": k, "rep": rep, "n_uni": int(uni.sum()), "n_bi_pairs": int(bi.sum()),
               "col_corr_median": float(np.median(cors))}
        for pen in pens:
            lams, est = path(sh, C, pen)
            r = path_metrics(lams, est, m_true); S = offdiag_support(est[r["best"]])
            rec[pen] = {"max_f1": r["max_f1"], "auc": r["auc"],
                "uni_correct_only": int(np.sum(uni & S & ~S.T)), "uni_reversed_only": int(np.sum(uni & ~S & S.T)),
                "uni_both": int(np.sum(uni & S & S.T)), "uni_none": int(np.sum(uni & ~S & ~S.T)),
                "bi_both": int(np.sum(bi & S & S.T)), "bi_one": int(np.sum(bi & (S ^ S.T))),
                "bi_none": int(np.sum(bi & ~S & ~S.T)),
                "false_pairs_selected": int(np.sum(np.triu(~(T|T.T) & (S|S.T), 1)))}
        out.append(rec)
        print(f"p={p} k={k} rep={rep} " + " ".join(f"{pen} {rec[pen]['max_f1']:.3f}" for pen in pens) + f" [{time.time()-t0:.0f}s]", flush=True)
        json.dump(out, open(f"pairs_p{p}_k{'-'.join(map(str,ks))}.json", "w"))
