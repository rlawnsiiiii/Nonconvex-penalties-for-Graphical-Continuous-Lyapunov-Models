import numpy as np
from gclm_mini import *
np.set_printoptions(precision=3, suppress=True, linewidth=120)

M = np.diag([-2.,-3.,-4.,-5.,-6.])
for a in range(4): M[a+1, a] = 0.65
M[0, 4] = 0.65
C = 2*np.eye(5); S = solve_lyapunov(M, C)
truth = (M != 0) & ~np.eye(5, dtype=bool)
print("true edges (i,j) with M_ij != 0:", list(zip(*np.nonzero(truth))))

for pen in ["lasso", "MCP"]:
    lams, est = path(S, C, pen, tol=1e-12)
    r = path_metrics(lams, est, M)
    b = r["best"]; s = offdiag_support(est[b])
    print(f"\n{pen}: best lambda = {lams[b]:.4f}  (lambda_max={lams.max():.4f})")
    print("  selected:", list(zip(*np.nonzero(s))))
    print("  missed  :", list(zip(*np.nonzero(truth & ~s))), " false:", list(zip(*np.nonzero(s & ~truth))))
    print("  breakdown:", orientation_breakdown(est[b], M))

kap = swap_curvature(S)
print("\nswap curvature on true-edge pairs:", {(i,j): round(kap[i,j],4) for i,j in zip(*np.nonzero(truth))})
print("coordinate curvature v_ij range:", end=" ")
v = np.array([[2*(np.sum(S[j]**2) + S[i,j]**2) for j in range(5)] for i in range(5)])
print(v[~np.eye(5,dtype=bool)].min().round(3), v[~np.eye(5,dtype=bool)].max().round(3))
print("1/gamma MCP =", round(1/3,3), " SCAD 1/(gamma-1) =", round(1/2.7,3))

# Is M* itself a local minimiser of the MCP objective for small lambda?
w = np.ones((5,5)); np.fill_diagonal(w, 0)
lmax = lambda_max(S, C)
print("\nlambda_max =", round(lmax,4))
for lam in [0.02, 0.05, 0.1, 0.2]:
    lams_, est_ = path(S, C, "MCP", lams=np.array(sorted(set(list(lmax*10**np.linspace(-4,0,100)) + [lam]))), tol=1e-12)
    idx = int(np.argmin(np.abs(lams_ - lam)))
    m_path = est_[idx]
    m_star_start = mapg(S, C, lam, w, "MCP", 3.0, M.copy(), tol=1e-13)
    F = lambda m: loss(m, S, C) + pen_value(m, lam, w, "MCP", 3.0)
    print(f"lam={lam:.3f}: F(path sol)={F(m_path):.6f}  F(start at M*)={F(m_star_start):.6f}  "
          f"moved from M* by {np.max(np.abs(m_star_start-M)):.1e}; "
          f"path support==truth? {np.array_equal(offdiag_support(m_path), truth)}; "
          f"M*-start support==truth? {np.array_equal(offdiag_support(m_star_start), truth)}")
