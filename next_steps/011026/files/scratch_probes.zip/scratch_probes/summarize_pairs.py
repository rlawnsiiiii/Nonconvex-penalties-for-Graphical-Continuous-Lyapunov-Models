"""Aggregate pairs_p10_k*.json: single edges vs 2-cycles at each method's best-F1 point."""
import json, glob, numpy as np
R = {}
for f in sorted(glob.glob("pairs_p10_k*.json")):
    for r in json.load(open(f)):
        R[(r["k"], r["rep"])] = r
R = list(R.values())
print("datasets:", len(R), "| single true edges:", np.mean([r["n_uni"] for r in R]),
      "| 2-cycle pairs:", np.mean([r["n_bi_pairs"] for r in R]))
print("median corr(design column M_ij, design column M_ji):",
      round(float(np.median([r["col_corr_median"] for r in R])), 3))
for pen in ("lasso", "MCP", "SCAD"):
    g = lambda k: float(np.mean([r[pen][k] for r in R]))
    hit = g("uni_correct_only") + g("uni_reversed_only") + g("uni_both")
    print(f"{pen:5s} max_f1 {g('max_f1'):.3f} | single: correct {g('uni_correct_only'):.2f} "
          f"hedge {g('uni_both'):.2f} reversed {g('uni_reversed_only'):.2f} none {g('uni_none'):.2f} "
          f"(of pair hit: {g('uni_correct_only')/hit:.2f}/{g('uni_both')/hit:.2f}/{g('uni_reversed_only')/hit:.2f}) "
          f"| 2-cycles both {g('bi_both'):.2f} one {g('bi_one'):.2f} none {g('bi_none'):.2f} "
          f"| false pairs {g('false_pairs_selected'):.2f}")
