# Scratch probes — 2026-10-01

Independent **mini re-implementation** of the S1b setup (not the repo code), written to check
mechanisms quickly. It reproduces the repo where checked (Example 2 at n = inf: lasso path
1.000/1.000, cycle 0.800/0.833; committed lasso `max_f1` for p=10, k=1, reps 0-5; the dataset
p=10, k=2, C_ID, rep 0 with lasso 0.596 / MCP 0.638). Regenerate any number with the repo
before it goes into the thesis. Needs numpy + scipy only; single core.

| file | what it does | runtime |
|---|---|---|
| `gclm_mini.py` | DGP with the repo's seeding, direct loss, FISTA (lasso), monotone APG (MCP/SCAD), continuation paths, metrics, orientation breakdown, reversal curvature | — |
| `test_basic.py` | closed form of the reversal curvature; Example 2 path/cycle at n = inf for lasso/MCP/SCAD | seconds |
| `test_cycle.py` | Example 2 cycle: which edge goes wrong; M* as MCP fixed point; objective comparison | seconds |
| `test_cycle2.py` | closing pair along the lasso path; l0 uniqueness of the true support; one reversal move; one-step LLA | ~1 min |
| `batch_p10.py` | p=10 C_ID: paired diffs, best-F1 breakdown, curvature stats, oracle-basin check, reversal search. `MAX_FLIPS=0 python3 batch_p10.py 10 10 C_ID 3` (args: p, reps, C, k list) | 1-2 min per k (reversal search: much longer) |
| `summarize.py` | aggregates `probe_p10_C_ID_k*.json` | seconds |
| `pairs.py` | single edges vs 2-cycles at best F1, design-column correlation. `python3 pairs.py 10 1,2 10 lasso,MCP,SCAD` | ~3 min per 2 k's |
| `summarize_pairs.py` | aggregates `pairs_p10_k*.json` | seconds |
| `*.json` | raw outputs behind the [scratch] numbers in the notes | — |

Conventions as in the repo: diagonal unpenalised, correlation input, C_est = 2I, grid
lambda_max * 10^linspace(-4, 0, 100), textbook MCP gamma=3 / SCAD gamma=3.7, tol 1e-8.
