import numpy as np, itertools
from gclm_mini import *
np.set_printoptions(precision=3, suppress=True, linewidth=120)

M = np.diag([-2.,-3.,-4.,-5.,-6.])
for a in range(4): M[a+1, a] = 0.65
M[0, 4] = 0.65
C = 2*np.eye(5); S = solve_lyapunov(M, C); p = 5
truth = (M != 0) & ~np.eye(p, dtype=bool)
w = np.ones((p,p)); np.fill_diagonal(w, 0)

# (1) the closing pair along the lasso path: does the true orientation ever carry mass?
lams, est = path(S, C, "lasso", tol=1e-12)
print("lambda/lmax    M[0,4](true 5->1)  M[4,0](false 1->5)   nnz")
for i in list(range(99, -1, -9)):
    m = est[i]; print(f"{lams[i]/lams.max():9.4f}      {m[0,4]:8.4f}          {m[4,0]:8.4f}        {offdiag_support(m).sum()}")

# (2) l0 view: which supports of size <= 5 admit an (almost) exact fit? (n = inf)
off = [(i,j) for i in range(p) for j in range(p) if i != j]
A_cols = {}
def design_col(i, j):
    E = np.zeros((p,p)); E[i,j] = 1.0
    return (E @ S + S @ E.T).ravel()
diag_cols = [design_col(i,i) for i in range(p)]
y = -C.ravel()
best = []
for size in range(3, 6):
    for supp in itertools.combinations(off, size):
        X = np.column_stack(diag_cols + [design_col(i,j) for i,j in supp])
        beta, res, rk, _ = np.linalg.lstsq(X, y, rcond=None)
        r = np.linalg.norm(X @ beta - y)
        if r < 1e-8: best.append((size, supp))
print("\nexact-fit supports with <= 5 off-diagonal edges:", best)

# (3) does a single 'reverse this edge' move from the continuation solution reach the truth?
lam = 0.05
Fm = lambda m: loss(m, S, C) + pen_value(m, lam, w, "MCP", 3.0)
lams2 = np.array(sorted(set(list(lams) + [lam])))
_, estm = path(S, C, "MCP", lams=lams2, tol=1e-12)
m0 = estm[int(np.argmin(np.abs(lams2 - lam)))]
print(f"\nMCP at lam={lam}: F = {Fm(m0):.6f}, support==truth: {np.array_equal(offdiag_support(m0), truth)}")
improved = True
cur = m0.copy()
while improved:
    improved = False
    for (i,j) in zip(*np.nonzero(offdiag_support(cur))):
        trial = cur.copy(); trial[j,i], trial[i,j] = trial[i,j], 0.0
        sol = mapg(S, C, lam, w, "MCP", 3.0, trial, tol=1e-12)
        if Fm(sol) < Fm(cur) - 1e-12:
            print(f"  reverse ({i},{j})->({j},{i}): F {Fm(cur):.6f} -> {Fm(sol):.6f}")
            cur, improved = sol, True
            break
print("after reversal search: support==truth:", np.array_equal(offdiag_support(cur), truth),
      " F =", round(Fm(cur),6))

# (4) one-step LLA (reweighted l1) from the lasso, MCP weights
lo = lam
lasso_sol = fista_wlasso(S, C, lo*w, diagonal_fit(S, C), tol=1e-12)
lasso_sol = est[int(np.argmin(np.abs(lams - lo)))] if False else lasso_sol
wts = np.maximum(1 - np.abs(lasso_sol)/(3*lo), 0) * w
lla = fista_wlasso(S, C, lo*wts, lasso_sol, tol=1e-12)
print("\nLLA from lasso at lam=0.05: support==truth:", np.array_equal(offdiag_support(lla), truth),
      " selected:", list(zip(*np.nonzero(offdiag_support(lla)))))
